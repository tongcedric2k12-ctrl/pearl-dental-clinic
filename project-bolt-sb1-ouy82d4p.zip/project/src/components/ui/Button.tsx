import { type ReactNode } from 'react';
import { ArrowRight } from 'lucide-react';

type Variant = 'primary' | 'secondary' | 'ghost' | 'outline';
type Size = 'sm' | 'md' | 'lg';

interface ButtonProps {
  children: ReactNode;
  href?: string;
  variant?: Variant;
  size?: Size;
  className?: string;
  onClick?: () => void;
  type?: 'button' | 'submit' | 'reset';
  'aria-label'?: string;
  icon?: boolean;
  target?: string;
  rel?: string;
  disabled?: boolean;
}

const base =
  'inline-flex items-center justify-center gap-2 font-medium transition-all duration-300 ease-smooth active:scale-[0.98] disabled:opacity-50 disabled:pointer-events-none';

const variants: Record<Variant, string> = {
  primary:
    'bg-navy-800 text-stone-50 hover:bg-navy-900 shadow-sm hover:shadow-md',
  secondary:
    'bg-stone-50 text-navy-800 border border-navy-200 hover:border-navy-400 hover:bg-stone-100',
  ghost:
    'text-navy-700 hover:text-navy-900 hover:bg-navy-50',
  outline:
    'text-navy-800 border border-navy-300 hover:border-navy-700 hover:bg-navy-50',
};

const sizes: Record<Size, string> = {
  sm: 'px-5 py-2.5 text-sm rounded-lg',
  md: 'px-7 py-3.5 text-sm rounded-lg',
  lg: 'px-8 py-4 text-base rounded-lg',
};

export function Button({
  children,
  href,
  variant = 'primary',
  size = 'md',
  className = '',
  onClick,
  type = 'button',
  'aria-label': ariaLabel,
  icon = false,
  target,
  rel,
  disabled,
}: ButtonProps) {
  const classes = `${base} ${variants[variant]} ${sizes[size]} ${className}`;

  const content = (
    <>
      {children}
      {icon && <ArrowRight className="h-4 w-4" />}
    </>
  );

  if (href) {
    return (
      <a
        href={href}
        className={classes}
        aria-label={ariaLabel}
        onClick={onClick}
        target={target}
        rel={rel}
        aria-disabled={disabled || undefined}
      >
        {content}
      </a>
    );
  }

  return (
    <button
      type={type}
      className={classes}
      aria-label={ariaLabel}
      onClick={onClick}
      disabled={disabled}
    >
      {content}
    </button>
  );
}
