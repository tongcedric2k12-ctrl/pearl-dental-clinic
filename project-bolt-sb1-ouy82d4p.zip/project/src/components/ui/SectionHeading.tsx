import { type ReactNode } from 'react';

interface SectionHeadingProps {
  eyebrow?: string;
  title: ReactNode;
  description?: string;
  align?: 'left' | 'center';
  className?: string;
  onDark?: boolean;
}

export function SectionHeading({
  eyebrow,
  title,
  description,
  align = 'left',
  className = '',
  onDark = false,
}: SectionHeadingProps) {
  const alignment =
    align === 'center'
      ? 'items-center text-center mx-auto'
      : 'items-start text-left';

  const titleColor = onDark ? 'text-stone-50' : '';
  const descColor = onDark ? 'text-stone-300' : 'text-ink-500';
  const eyebrowColor = onDark ? 'text-stone-400' : '';

  return (
    <div className={`flex flex-col gap-4 ${alignment} ${className}`}>
      {eyebrow && (
        <span className={`eyebrow ${eyebrowColor}`}>{eyebrow}</span>
      )}
      <h2 className={`font-serif text-3xl sm:text-4xl lg:text-[2.75rem] leading-[1.1] text-balance max-w-2xl ${titleColor}`}>
        {title}
      </h2>
      {description && (
        <p className={`${descColor} text-base lg:text-lg leading-relaxed max-w-xl text-pretty`}>
          {description}
        </p>
      )}
    </div>
  );
}
