import { branding } from '@/data/site';

export function Logo({
  className = '',
  variant = 'dark',
}: {
  className?: string;
  variant?: 'dark' | 'light';
}) {
  const main = variant === 'light' ? 'text-stone-50' : 'text-ink-900';
  const sub = variant === 'light' ? 'text-stone-200' : 'text-ink-400';

  return (
    <span className={`inline-flex flex-col leading-none ${className}`}>
      <span className={`font-serif text-lg font-medium tracking-tight ${main}`}>
        {branding.logoText}
      </span>
      <span
        className={`text-[0.625rem] font-medium uppercase tracking-[0.22em] ${sub}`}
      >
        {branding.logoSubtext}
      </span>
    </span>
  );
}
