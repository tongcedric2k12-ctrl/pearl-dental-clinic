import { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';
import { navigation, clinicInfo } from '@/data/site';
import { Button } from '@/components/ui/Button';
import { Logo } from '@/components/ui/Logo';
import { useScrollPosition } from '@/hooks/useScrollReveal';

export function Navbar() {
  const scrolled = useScrollPosition();
  const [menuOpen, setMenuOpen] = useState(false);

  const onDark = !scrolled;
  const logoVariant = onDark ? 'light' : 'dark';
  const navLinkColor = onDark
    ? 'text-stone-200/90 hover:text-stone-50'
    : 'text-ink-600 hover:text-ink-900';
  const callLinkColor = onDark
    ? 'text-stone-200/90 hover:text-stone-50'
    : 'text-ink-600 hover:text-ink-900';
  const hamburgerColor = onDark ? 'text-stone-50' : 'text-ink-800';

  useEffect(() => {
    if (menuOpen) {
      document.body.style.overflow = 'hidden';
      return () => { document.body.style.overflow = ''; };
    }
  }, [menuOpen]);

  return (
    <>
      <header
        className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ease-smooth ${
          scrolled
            ? 'bg-stone-50/90 backdrop-blur-md border-b border-ink-100 shadow-sm'
            : 'bg-transparent border-b border-transparent'
        }`}
      >
        <nav
          className="mx-auto flex max-w-content items-center justify-between container-px h-16 lg:h-20"
          aria-label="Primary navigation"
        >
          <a
            href="#home"
            aria-label="Northstar Dental Studio — Home"
            className="shrink-0"
          >
            <Logo variant={logoVariant} />
          </a>

          <ul className="hidden lg:flex items-center gap-8">
            {navigation.map((item) => (
              <li key={item.href}>
                <a
                  href={item.href}
                  className={`link-underline text-sm font-medium transition-colors ${navLinkColor}`}
                >
                  {item.label}
                </a>
              </li>
            ))}
          </ul>

          <div className="hidden lg:flex items-center gap-4">
            <a
              href={clinicInfo.phoneHref}
              className={`text-sm font-medium transition-colors ${callLinkColor}`}
            >
              Call
            </a>
            <Button href={clinicInfo.bookingUrl} size="sm">
              Book an Appointment
            </Button>
          </div>

          <button
            className={`lg:hidden p-2 -mr-2 transition-colors ${hamburgerColor}`}
            onClick={() => setMenuOpen(true)}
            aria-label="Open menu"
            aria-expanded={menuOpen}
          >
            <Menu className="h-6 w-6" />
          </button>
        </nav>
      </header>

      {menuOpen && (
        <MobileMenu onClose={() => setMenuOpen(false)} />
      )}
    </>
  );
}

function MobileMenu({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-[60] lg:hidden">
      <div
        className="absolute inset-0 bg-ink-950/40 backdrop-blur-sm animate-fade-in"
        onClick={onClose}
        aria-hidden="true"
      />
      <div className="absolute right-0 top-0 h-full w-full max-w-sm bg-stone-50 shadow-xl animate-slide-down flex flex-col">
        <div className="flex items-center justify-between container-px h-16 border-b border-ink-100 shrink-0">
          <Logo variant="dark" />
          <button
            className="p-2 -mr-2 text-ink-600 hover:text-ink-900 transition-colors"
            onClick={onClose}
            aria-label="Close menu"
          >
            <X className="h-6 w-6" />
          </button>
        </div>
        <nav className="container-px py-6 flex-1 overflow-y-auto" aria-label="Mobile navigation">
          <ul className="flex flex-col gap-1">
            {navigation.map((item) => (
              <li key={item.href}>
                <a
                  href={item.href}
                  onClick={onClose}
                  className="block py-3.5 text-base font-medium text-ink-800 hover:text-navy-700 border-b border-ink-100/60 transition-colors"
                >
                  {item.label}
                </a>
              </li>
            ))}
          </ul>
          <div className="mt-8 flex flex-col gap-3">
            <Button href={clinicInfo.bookingUrl} size="lg" onClick={onClose} className="w-full">
              Book an Appointment
            </Button>
            <Button
              href={clinicInfo.phoneHref}
              variant="secondary"
              size="lg"
              onClick={onClose}
              className="w-full"
            >
              Call the Clinic
            </Button>
          </div>
        </nav>
      </div>
    </div>
  );
}
