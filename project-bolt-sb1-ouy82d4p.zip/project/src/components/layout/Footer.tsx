import { navigation, clinicInfo, socialLinks } from '@/data/site';
import { Logo } from '@/components/ui/Logo';
import { Instagram, Facebook, Phone, Mail, MapPin } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-navy-950 text-stone-100">
      <div className="mx-auto max-w-content container-px py-16 lg:py-20">
        <div className="grid grid-cols-1 gap-12 md:grid-cols-2 lg:grid-cols-4 lg:gap-8">
          <div className="lg:col-span-1">
            <Logo variant="light" />
            <p className="mt-5 text-sm leading-relaxed text-stone-300 max-w-xs">
              {clinicInfo.tagline}
            </p>
            <div className="mt-6 flex gap-3">
              <a
                href={socialLinks.instagram}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Instagram"
                className="flex h-9 w-9 items-center justify-center rounded-lg bg-navy-800/60 text-stone-300 hover:bg-navy-700 hover:text-stone-50 transition-colors"
              >
                <Instagram className="h-4 w-4" />
              </a>
              <a
                href={socialLinks.facebook}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Facebook"
                className="flex h-9 w-9 items-center justify-center rounded-lg bg-navy-800/60 text-stone-300 hover:bg-navy-700 hover:text-stone-50 transition-colors"
              >
                <Facebook className="h-4 w-4" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-xs font-semibold uppercase tracking-[0.18em] text-stone-400 mb-5">
              Explore
            </h3>
            <ul className="flex flex-col gap-3">
              {navigation.map((item) => (
                <li key={item.href}>
                  <a
                    href={item.href}
                    className="text-sm text-stone-300 hover:text-stone-50 transition-colors"
                  >
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-xs font-semibold uppercase tracking-[0.18em] text-stone-400 mb-5">
              Contact
            </h3>
            <ul className="flex flex-col gap-4 text-sm text-stone-300">
              <li className="flex items-start gap-3">
                <MapPin className="h-4 w-4 mt-0.5 text-stone-500 shrink-0" />
                <span>{clinicInfo.address}</span>
              </li>
              <li>
                <a
                  href={clinicInfo.phoneHref}
                  className="flex items-start gap-3 hover:text-stone-50 transition-colors"
                >
                  <Phone className="h-4 w-4 mt-0.5 text-stone-500 shrink-0" />
                  <span>{clinicInfo.phone}</span>
                </a>
              </li>
              <li>
                <a
                  href={clinicInfo.emailHref}
                  className="flex items-start gap-3 hover:text-stone-50 transition-colors"
                >
                  <Mail className="h-4 w-4 mt-0.5 text-stone-500 shrink-0" />
                  <span>{clinicInfo.email}</span>
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-xs font-semibold uppercase tracking-[0.18em] text-stone-400 mb-5">
              Opening Hours
            </h3>
            <ul className="flex flex-col gap-2.5 text-sm">
              {clinicInfo.openingHours.map((entry) => (
                <li
                  key={entry.day}
                  className="flex justify-between text-stone-300"
                >
                  <span>{entry.day}</span>
                  <span className="text-stone-400">{entry.hours}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-14 border-t border-navy-800/60 pt-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <p className="text-xs text-stone-400">
            &copy; {new Date().getFullYear()} {clinicInfo.clinicName}. All rights reserved.
          </p>
          <div className="flex gap-6">
            <a href="#" className="text-xs text-stone-400 hover:text-stone-50 transition-colors">
              Privacy Policy
            </a>
            <a href="#" className="text-xs text-stone-400 hover:text-stone-50 transition-colors">
              Terms
            </a>
            <a href="#" className="text-xs text-stone-400 hover:text-stone-50 transition-colors">
              Accessibility
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
