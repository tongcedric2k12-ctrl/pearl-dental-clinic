import { clinicInfo } from '@/data/site';
import { Phone, CalendarCheck } from 'lucide-react';

export function MobileStickyCTA() {
  return (
    <div
      className="fixed inset-x-0 bottom-0 z-40 lg:hidden"
      style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
    >
      <div className="grid grid-cols-2 gap-px bg-ink-100/80 backdrop-blur-md border-t border-ink-100/80">
        <a
          href={clinicInfo.phoneHref}
          className="flex items-center justify-center gap-2 bg-stone-50/95 py-3.5 text-sm font-medium text-ink-700 active:bg-stone-100 transition-colors"
        >
          <Phone className="h-4 w-4 text-navy-600" />
          Call
        </a>
        <a
          href={clinicInfo.bookingUrl}
          className="flex items-center justify-center gap-2 bg-navy-800 py-3.5 text-sm font-medium text-stone-50 active:bg-navy-900 transition-colors"
        >
          <CalendarCheck className="h-4 w-4" />
          Book
        </a>
      </div>
    </div>
  );
}
