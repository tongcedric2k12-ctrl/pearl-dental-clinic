import { images, clinicInfo } from '@/data/site';
import { Container } from '@/components/ui/Container';
import { Button } from '@/components/ui/Button';
import { Reveal } from '@/components/ui/Reveal';

export function AboutSection() {
  return (
    <section id="about" className="section-py bg-stone-100 overflow-hidden">
      <Container>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          <Reveal className="order-1">
            <div className="relative">
              <div className="aspect-[4/5] overflow-hidden rounded-lg">
                <img
                  src={images.aboutMain}
                  alt="Dentist consulting with patient using a tablet in a modern clinic"
                  loading="lazy"
                  className="h-full w-full object-cover"
                />
              </div>
              <div className="absolute -bottom-8 -right-4 lg:-right-12 w-40 h-52 lg:w-52 lg:h-64 overflow-hidden rounded-lg border-4 lg:border-8 border-stone-100 shadow-xl">
                <img
                  src={images.aboutSecondary}
                  alt="Dentist welcoming a patient at the clinic reception"
                  loading="lazy"
                  className="h-full w-full object-cover"
                />
              </div>
            </div>
          </Reveal>

          <div className="order-2">
            <Reveal>
              <span className="eyebrow">About Us</span>
              <h2 className="mt-5 font-serif text-3xl sm:text-4xl leading-[1.1] text-ink-900 text-balance">
                Considered care with a human approach.
              </h2>
              <div className="mt-6 space-y-4 text-ink-600 leading-relaxed text-pretty">
                <p>
                  At {clinicInfo.clinicName}, we take the time to understand
                  each patient's needs, concerns and goals before recommending
                  any treatment.
                </p>
                <p>
                  Our approach combines modern dentistry with clear
                  communication and a calm environment — because feeling
                  informed and comfortable is just as important as the
                  treatment itself.
                </p>
              </div>

              <div className="mt-10 grid grid-cols-3 gap-6 border-t border-ink-100 pt-8">
                <div>
                  <p className="font-serif text-2xl text-navy-800">1:1</p>
                  <p className="mt-1 text-xs text-ink-400 leading-relaxed">
                    Dedicated consultation time
                  </p>
                </div>
                <div>
                  <p className="font-serif text-2xl text-navy-800">3D</p>
                  <p className="mt-1 text-xs text-ink-400 leading-relaxed">
                    Digital scanning &amp; imaging
                  </p>
                </div>
                <div>
                  <p className="font-serif text-2xl text-navy-800">Full</p>
                  <p className="mt-1 text-xs text-ink-400 leading-relaxed">
                    Treatment transparency
                  </p>
                </div>
              </div>

              <div className="mt-8">
                <Button href="#team" variant="primary" size="md" icon>
                  Meet Our Team
                </Button>
              </div>
            </Reveal>
          </div>
        </div>
      </Container>
    </section>
  );
}
