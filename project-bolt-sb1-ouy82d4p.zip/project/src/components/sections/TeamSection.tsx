import { team } from '@/data/site';
import { Container } from '@/components/ui/Container';
import { SectionHeading } from '@/components/ui/SectionHeading';
import { Reveal } from '@/components/ui/Reveal';

export function TeamSection() {
  return (
    <section id="team" className="section-py bg-stone-50">
      <Container>
        <SectionHeading
          eyebrow="Our Team"
          title="Meet the team."
          description="Our dentists are here to provide considered care tailored to your individual needs."
          className="mb-14 lg:mb-20"
        />

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 lg:gap-10">
          {team.map((member, index) => (
            <Reveal key={member.id} delay={index * 100}>
              <article className="group flex flex-col">
                <div className="relative aspect-[4/5] overflow-hidden rounded-lg bg-ink-100">
                  <img
                    src={member.image}
                    alt={`${member.name} — ${member.role}`}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-500 ease-smooth group-hover:scale-[1.03]"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-ink-950/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                </div>

                <div className="mt-5 flex flex-col gap-3">
                  <div>
                    <h3 className="text-lg font-medium text-ink-900">
                      {member.name}
                    </h3>
                    <p className="text-sm text-navy-600 mt-0.5">{member.role}</p>
                  </div>

                  <p className="text-sm leading-relaxed text-ink-500 text-pretty">
                    {member.bio}
                  </p>

                  <div className="mt-1">
                    <h4 className="text-xs font-semibold uppercase tracking-[0.14em] text-ink-400 mb-2.5">
                      Areas of Interest
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {member.areas.map((area) => (
                        <span
                          key={area}
                          className="inline-flex items-center text-xs font-medium text-ink-600 bg-stone-100 border border-ink-100 px-3 py-1.5 rounded-md"
                        >
                          {area}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </article>
            </Reveal>
          ))}
        </div>

      </Container>
    </section>
  );
}
