import { clinicInfo } from '@/data/site';
import { Container } from '@/components/ui/Container';
import { SectionHeading } from '@/components/ui/SectionHeading';
import { Button } from '@/components/ui/Button';
import { Reveal } from '@/components/ui/Reveal';
import { Phone, Mail, MapPin, Clock, Navigation } from 'lucide-react';

export function ContactSection() {
  return (
    <section id="contact" className="section-py bg-stone-50">
      <Container>
        <SectionHeading
          eyebrow="Contact"
          title="Get in touch."
          description="We're here to help. Reach out with any questions or to discuss your appointment."
          className="mb-14 lg:mb-20"
        />

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10">
          <div className="lg:col-span-5">
            <Reveal>
              <div className="flex flex-col gap-6">
                <ContactRow
                  icon={<MapPin className="h-5 w-5" />}
                  label="Address"
                  value={clinicInfo.address}
                />
                <ContactRow
                  icon={<Phone className="h-5 w-5" />}
                  label="Phone"
                  value={clinicInfo.phone}
                  href={clinicInfo.phoneHref}
                />
                <ContactRow
                  icon={<Mail className="h-5 w-5" />}
                  label="Email"
                  value={clinicInfo.email}
                  href={clinicInfo.emailHref}
                />
                <div>
                  <div className="flex items-center gap-3 mb-4">
                    <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-navy-50 text-navy-700">
                      <Clock className="h-5 w-5" />
                    </span>
                    <span className="text-sm font-medium text-ink-700">
                      Opening Hours
                    </span>
                  </div>
                  <ul className="flex flex-col gap-2 ml-14">
                    {clinicInfo.openingHours.map((entry) => (
                      <li
                        key={entry.day}
                        className="flex justify-between text-sm text-ink-500 border-b border-ink-100/60 pb-2"
                      >
                        <span>{entry.day}</span>
                        <span className="text-ink-600">{entry.hours}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="flex flex-col sm:flex-row gap-3 mt-2">
                  <Button href={clinicInfo.phoneHref} size="md" className="w-full sm:w-auto">
                    <Phone className="h-4 w-4" />
                    Call
                  </Button>
                  <Button
                    href={clinicInfo.emailHref}
                    variant="secondary"
                    size="md"
                    className="w-full sm:w-auto"
                  >
                    Email
                  </Button>
                </div>
              </div>
            </Reveal>
          </div>

          <div className="lg:col-span-7">
            <Reveal delay={100}>
              <div className="relative aspect-[4/3] lg:aspect-auto lg:h-full min-h-[400px] overflow-hidden rounded-lg bg-stone-100 border border-ink-100">
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center p-8">
                    <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-lg bg-navy-50 text-navy-600 mb-4">
                      <Navigation className="h-6 w-6" />
                    </div>
                    <p className="text-sm font-medium text-ink-700">
                      Map will display here
                    </p>
                    <p className="mt-2 text-xs text-ink-400 max-w-xs mx-auto">
                      Replace with an embedded Google Maps showing the clinic's
                      actual location.
                    </p>
                    <div className="mt-5">
                      <Button
                        href={clinicInfo.mapsUrl}
                        variant="outline"
                        size="sm"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        Get Directions
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </Container>
    </section>
  );
}

function ContactRow({
  icon,
  label,
  value,
  href,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  href?: string;
}) {
  return (
    <div className="flex items-start gap-4">
      <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-navy-50 text-navy-700 shrink-0">
        {icon}
      </span>
      <div>
        <p className="text-xs font-semibold uppercase tracking-[0.14em] text-ink-400 mb-1">
          {label}
        </p>
        {href ? (
          <a
            href={href}
            className="text-sm text-ink-700 hover:text-navy-700 transition-colors"
          >
            {value}
          </a>
        ) : (
          <p className="text-sm text-ink-600">{value}</p>
        )}
      </div>
    </div>
  );
}
