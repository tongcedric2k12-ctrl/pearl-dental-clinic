import { useState, useRef, useEffect, useId, type FormEvent } from 'react';
import { Container } from '@/components/ui/Container';
import { Reveal } from '@/components/ui/Reveal';
import { Button } from '@/components/ui/Button';
import { treatments } from '@/data/site';
import { CheckCircle2, CalendarClock, ShieldCheck } from 'lucide-react';

interface FormData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  preferredDate: string;
  preferredTime: string;
  treatment: string;
  message: string;
}

interface FormErrors {
  firstName?: string;
  lastName?: string;
  email?: string;
  phone?: string;
  preferredDate?: string;
}

const initialData: FormData = {
  firstName: '',
  lastName: '',
  email: '',
  phone: '',
  preferredDate: '',
  preferredTime: '',
  treatment: '',
  message: '',
};

const timeSlots = [
  'Morning (8:00 – 12:00)',
  'Afternoon (12:00 – 4:00)',
  'Late afternoon (4:00 – 6:00)',
];

export function BookingSection() {
  const [data, setData] = useState<FormData>(initialData);
  const [errors, setErrors] = useState<FormErrors>({});
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const successRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (submitted && successRef.current) {
      successRef.current.focus();
    }
  }, [submitted]);

  const validate = (): FormErrors => {
    const e: FormErrors = {};
    if (!data.firstName.trim()) e.firstName = 'Please enter your first name.';
    if (!data.lastName.trim()) e.lastName = 'Please enter your last name.';
    if (!data.email.trim()) {
      e.email = 'Please enter your email address.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
      e.email = 'Please enter a valid email address.';
    }
    if (!data.phone.trim()) {
      e.phone = 'Please enter your phone number.';
    }
    if (!data.preferredDate) {
      e.preferredDate = 'Please select a preferred date.';
    }
    return e;
  };

  const handleChange = (
    field: keyof FormData,
    value: string
  ) => {
    setData((prev) => ({ ...prev, [field]: value }));
    if (errors[field as keyof FormErrors]) {
      setErrors((prev) => ({ ...prev, [field]: undefined }));
    }
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (submitting) return;
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    setSubmitting(true);
    setTimeout(() => {
      setSubmitting(false);
      setSubmitted(true);
    }, 800);
  };

  const handleReset = () => {
    setData(initialData);
    setErrors({});
    setSubmitted(false);
  };

  return (
    <section id="booking" className="section-py bg-stone-100">
      <Container>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16">
          <div className="lg:col-span-5">
            <Reveal>
              <span className="eyebrow">Book an Appointment</span>
              <h2 className="mt-5 font-serif text-3xl sm:text-4xl lg:text-[2.75rem] leading-[1.1] text-ink-900 text-balance">
                Let's take the next step.
              </h2>
              <p className="mt-5 text-ink-500 leading-relaxed text-pretty">
                Tell us a little about what you're looking for and our team will
                contact you regarding availability.
              </p>

              <div className="mt-8 space-y-4">
                <div className="flex items-start gap-3">
                  <ShieldCheck className="h-5 w-5 text-navy-600 mt-0.5 shrink-0" />
                  <p className="text-sm text-ink-600 leading-relaxed">
                    Appointment requests are reviewed by our team — we'll
                    contact you to confirm availability.
                  </p>
                </div>
                <div className="flex items-start gap-3">
                  <CalendarClock className="h-5 w-5 text-navy-600 mt-0.5 shrink-0" />
                  <p className="text-sm text-ink-600 leading-relaxed">
                    Prefer to call? You can reach us directly during opening
                    hours.
                  </p>
                </div>
              </div>

            </Reveal>
          </div>

          <div className="lg:col-span-7">
            <Reveal delay={100}>
              {submitted ? (
                <SuccessState ref={successRef} onReset={handleReset} />
              ) : (
                <form
                  onSubmit={handleSubmit}
                  noValidate
                  className="bg-stone-50 border border-ink-100 rounded-lg p-6 sm:p-8"
                  aria-label="Appointment request form"
                >
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <Field
                      label="First Name"
                      required
                      error={errors.firstName}
                    >
                      {(id) => (
                        <input
                          id={id}
                          type="text"
                          value={data.firstName}
                          onChange={(e) =>
                            handleChange('firstName', e.target.value)
                          }
                          placeholder="Jane"
                          aria-required="true"
                          aria-invalid={!!errors.firstName}
                          aria-describedby={errors.firstName ? `${id}-error` : undefined}
                          className={`input-base ${errors.firstName ? 'input-error' : ''}`}
                        />
                      )}
                    </Field>

                    <Field
                      label="Last Name"
                      required
                      error={errors.lastName}
                    >
                      {(id) => (
                        <input
                          id={id}
                          type="text"
                          value={data.lastName}
                          onChange={(e) =>
                            handleChange('lastName', e.target.value)
                          }
                          placeholder="Smith"
                          aria-required="true"
                          aria-invalid={!!errors.lastName}
                          aria-describedby={errors.lastName ? `${id}-error` : undefined}
                          className={`input-base ${errors.lastName ? 'input-error' : ''}`}
                        />
                      )}
                    </Field>

                    <Field label="Email" required error={errors.email}>
                      {(id) => (
                        <input
                          id={id}
                          type="email"
                          value={data.email}
                          onChange={(e) =>
                            handleChange('email', e.target.value)
                          }
                          placeholder="jane.smith@email.com"
                          aria-required="true"
                          aria-invalid={!!errors.email}
                          aria-describedby={errors.email ? `${id}-error` : undefined}
                          className={`input-base ${errors.email ? 'input-error' : ''}`}
                        />
                      )}
                    </Field>

                    <Field label="Phone" required error={errors.phone}>
                      {(id) => (
                        <input
                          id={id}
                          type="tel"
                          value={data.phone}
                          onChange={(e) =>
                            handleChange('phone', e.target.value)
                          }
                          placeholder="04XX XXX XXX"
                          aria-required="true"
                          aria-invalid={!!errors.phone}
                          aria-describedby={errors.phone ? `${id}-error` : undefined}
                          className={`input-base ${errors.phone ? 'input-error' : ''}`}
                        />
                      )}
                    </Field>

                    <Field
                      label="Preferred Date"
                      required
                      error={errors.preferredDate}
                    >
                      {(id) => (
                        <input
                          id={id}
                          type="date"
                          value={data.preferredDate}
                          min={new Date().toISOString().split('T')[0]}
                          onChange={(e) =>
                            handleChange('preferredDate', e.target.value)
                          }
                          aria-required="true"
                          aria-invalid={!!errors.preferredDate}
                          aria-describedby={errors.preferredDate ? `${id}-error` : undefined}
                          className={`input-base ${errors.preferredDate ? 'input-error' : ''}`}
                        />
                      )}
                    </Field>

                    <Field label="Preferred Time">
                      {(id) => (
                        <select
                          id={id}
                          value={data.preferredTime}
                          onChange={(e) =>
                            handleChange('preferredTime', e.target.value)
                          }
                          className="input-base"
                        >
                          <option value="">Select a time</option>
                          {timeSlots.map((slot) => (
                            <option key={slot} value={slot}>
                              {slot}
                            </option>
                          ))}
                        </select>
                      )}
                    </Field>

                    <div className="sm:col-span-2">
                      <Field label="Treatment / Reason for Visit">
                        {(id) => (
                          <select
                            id={id}
                            value={data.treatment}
                            onChange={(e) =>
                              handleChange('treatment', e.target.value)
                            }
                            className="input-base"
                          >
                            <option value="">Select a treatment (optional)</option>
                            {treatments.map((t) => (
                              <option key={t.id} value={t.name}>
                                {t.name}
                              </option>
                            ))}
                            <option value="Other">Other / Not sure</option>
                          </select>
                        )}
                      </Field>
                    </div>

                    <div className="sm:col-span-2">
                      <Field label="Message">
                        {(id) => (
                          <textarea
                            id={id}
                            value={data.message}
                            onChange={(e) =>
                              handleChange('message', e.target.value)
                            }
                            placeholder="Tell us a little about what you're looking for..."
                            rows={4}
                            className="input-base resize-none"
                          />
                        )}
                      </Field>
                    </div>
                  </div>

                  <div className="mt-6 flex flex-col sm:flex-row items-start sm:items-center gap-4">
                    <Button
                      type="submit"
                      size="lg"
                      className="w-full sm:w-auto"
                      disabled={submitting}
                    >
                      {submitting ? 'Sending...' : 'Request an Appointment'}
                    </Button>
                    <p className="text-xs text-ink-400 leading-relaxed">
                      By submitting, you agree to be contacted regarding your
                      appointment request.
                    </p>
                  </div>
                </form>
              )}
            </Reveal>
          </div>
        </div>
      </Container>
    </section>
  );
}

function Field({
  label,
  required,
  error,
  children,
}: {
  label: string;
  required?: boolean;
  error?: string;
  children: (id: string) => React.ReactNode;
}) {
  const id = useId();
  return (
    <div>
      <label htmlFor={id} className="block text-sm font-medium text-ink-700 mb-1.5">
        {label}
        {required && <span className="text-accent-500 ml-0.5">*</span>}
      </label>
      {children(id)}
      {error && (
        <p id={`${id}-error`} className="mt-1.5 text-xs text-red-600" role="alert">
          {error}
        </p>
      )}
    </div>
  );
}

function SuccessState({
  onReset,
  ref,
}: {
  onReset: () => void;
  ref: React.RefObject<HTMLDivElement>;
}) {
  return (
    <div
      ref={ref}
      tabIndex={-1}
      className="bg-stone-50 border border-ink-100 rounded-lg p-8 sm:p-12 text-center focus:outline-none"
      role="status"
      aria-live="polite"
    >
      <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-green-50 text-green-600">
        <CheckCircle2 className="h-8 w-8" />
      </div>
      <h3 className="mt-6 font-serif text-2xl text-ink-900">
        Thank you. Your appointment request has been received.
      </h3>
      <p className="mt-3 text-sm text-ink-500 leading-relaxed max-w-md mx-auto text-pretty">
        Our team will contact you to confirm availability. If your request is
        urgent, please call the clinic directly.
      </p>
      <div className="mt-8">
        <Button variant="secondary" size="md" onClick={onReset}>
          Submit another request
        </Button>
      </div>
    </div>
  );
}
