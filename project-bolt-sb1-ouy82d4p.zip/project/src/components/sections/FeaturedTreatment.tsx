import { images } from '@/data/site';
import { Container } from '@/components/ui/Container';
import { Button } from '@/components/ui/Button';
import { Reveal } from '@/components/ui/Reveal';

const cosmeticOptions = [
  'Teeth Whitening',
  'Veneers',
  'Smile Enhancement',
  'Comprehensive Smile Planning',
];

export function FeaturedTreatment() {
  return (
    <section className="bg-stone-50 section-py overflow-hidden">
      <Container>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16 items-center">
          <Reveal className="lg:col-span-7 order-1">
            <div className="relative">
              <div className="relative aspect-[4/5] sm:aspect-[5/4] lg:aspect-[4/5] overflow-hidden rounded-lg">
                <img
                  src={images.cosmetic}
                  alt="Cosmetic dentistry treatment showing natural-looking results"
                  loading="lazy"
                  className="h-full w-full object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -right-4 lg:-right-8 bg-navy-900 text-stone-50 px-7 py-6 rounded-lg shadow-xl max-w-[220px]">
                <p className="font-serif text-3xl leading-none">Cosmetic</p>
                <p className="mt-2 text-xs uppercase tracking-[0.16em] text-stone-300">
                  Dentistry
                </p>
                <p className="mt-3 text-sm text-stone-300/80 leading-relaxed">
                  Tailored to your smile and facial features.
                </p>
              </div>
            </div>
          </Reveal>

          <div className="lg:col-span-5 order-2">
            <Reveal>
              <span className="eyebrow">Featured</span>
              <h2 className="mt-5 font-serif text-3xl sm:text-4xl leading-[1.1] text-ink-900 text-balance">
                Natural-looking smiles, thoughtfully designed.
              </h2>
              <p className="mt-5 text-ink-500 leading-relaxed text-pretty">
                Explore personalised cosmetic treatment options designed around your goals, smile and overall appearance.
              </p>

              <ul className="mt-8 flex flex-col gap-3">
                {cosmeticOptions.map((option) => (
                  <li
                    key={option}
                    className="flex items-center gap-3 text-sm text-ink-700"
                  >
                    <span className="h-1.5 w-1.5 rounded-full bg-accent-400" />
                    {option}
                  </li>
                ))}
              </ul>

              <div className="mt-9">
                <Button
                  href="#treatments"
                  variant="outline"
                  size="md"
                  icon
                >
                  Explore Cosmetic Dentistry
                </Button>
              </div>
            </Reveal>
          </div>
        </div>
      </Container>
    </section>
  );
}
