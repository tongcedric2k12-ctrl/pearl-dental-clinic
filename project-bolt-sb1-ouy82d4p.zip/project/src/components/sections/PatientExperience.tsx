import { images } from '@/data/site';
import { Container } from '@/components/ui/Container';
import { Reveal } from '@/components/ui/Reveal';

const experienceItems = [
  {
    label: 'Reception',
    image: images.experienceReception,
    alt: 'Welcoming reception area at a modern dental clinic',
    span: 'lg:col-span-2 lg:row-span-2',
  },
  {
    label: 'Consultation',
    image: images.experienceConsultation,
    alt: 'Dentist consulting with patient in a bright treatment room',
    span: 'lg:col-span-1',
  },
  {
    label: 'Treatment',
    image: images.experienceTreatment,
    alt: 'Modern dental treatment room with clean equipment',
    span: 'lg:col-span-1',
  },
  {
    label: 'Patient Care',
    image: images.experienceInteraction,
    alt: 'Dental professionals interacting with patient using a tablet',
    span: 'lg:col-span-2',
  },
];

const messaging = ['Calm', 'Welcoming', 'Professional', 'Modern', 'Comfortable'];

export function PatientExperience() {
  return (
    <section id="experience" className="section-py bg-stone-100 overflow-hidden">
      <Container>
        <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between mb-12 lg:mb-16">
          <Reveal>
            <span className="eyebrow">Patient Experience</span>
            <h2 className="mt-5 font-serif text-3xl sm:text-4xl lg:text-[2.75rem] leading-[1.1] text-ink-900 text-balance">
              Designed to feel different.
            </h2>
          </Reveal>
          <Reveal delay={100}>
            <div className="flex flex-wrap gap-x-6 gap-y-2 lg:justify-end lg:max-w-sm">
              {messaging.map((word) => (
                <span
                  key={word}
                  className="text-sm font-medium uppercase tracking-[0.12em] text-ink-400"
                >
                  {word}
                </span>
              ))}
            </div>
          </Reveal>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 lg:grid-rows-2 gap-4 lg:gap-5 lg:auto-rows-[220px]">
          {experienceItems.map((item, index) => (
            <Reveal
              key={item.label}
              delay={index * 80}
              className={item.span}
            >
              <div className="group relative h-full min-h-[200px] overflow-hidden rounded-lg">
                <img
                  src={item.image}
                  alt={item.alt}
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-500 ease-smooth group-hover:scale-[1.03]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink-950/70 via-transparent to-transparent" />
                <span className="absolute bottom-4 left-4 text-sm font-medium text-stone-50">
                  {item.label}
                </span>
              </div>
            </Reveal>
          ))}
        </div>
      </Container>
    </section>
  );
}
