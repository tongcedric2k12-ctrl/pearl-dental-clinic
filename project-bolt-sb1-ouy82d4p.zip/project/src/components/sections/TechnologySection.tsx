import { technology, images } from '@/data/site';
import { Container } from '@/components/ui/Container';
import { Reveal } from '@/components/ui/Reveal';
import { Button } from '@/components/ui/Button';

export function TechnologySection() {
  return (
    <section className="section-py bg-stone-50 overflow-hidden">
      <Container>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16 items-center">
          <Reveal className="lg:col-span-5 order-2 lg:order-1">
            <span className="eyebrow">Technology</span>
            <h2 className="mt-5 font-serif text-3xl sm:text-4xl lg:text-[2.75rem] leading-[1.1] text-ink-900 text-balance">
              Modern technology, thoughtful dentistry.
            </h2>
            <p className="mt-5 text-ink-500 leading-relaxed text-pretty">
              Contemporary tools that support thorough assessment, comfortable treatment and clear communication — designed to make your experience better, not more complex.
            </p>

            <div className="mt-8 flex flex-col gap-7">
              {technology.map((item) => (
                <div key={item.title} className="border-l-2 border-navy-100 pl-5">
                  <h3 className="text-base font-medium text-ink-900">
                    {item.title}
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-ink-500 text-pretty">
                    {item.description}
                  </p>
                  <p className="mt-2 text-sm font-medium text-navy-600">
                    {item.benefit}
                  </p>
                </div>
              ))}
            </div>

            <div className="mt-9">
              <Button href="#why-us" variant="outline" size="md" icon>
                Explore Our Approach
              </Button>
            </div>
          </Reveal>

          <Reveal className="lg:col-span-7 order-1 lg:order-2">
            <div className="relative">
              <div className="aspect-[4/3] lg:aspect-[5/4] overflow-hidden rounded-lg">
                <img
                  src={images.treatmentRoom}
                  alt="Modern dental treatment room with digital equipment"
                  loading="lazy"
                  className="h-full w-full object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -left-4 lg:-left-8 bg-stone-50 border border-ink-100 px-6 py-5 rounded-lg shadow-lg max-w-[240px]">
                <p className="font-serif text-lg text-ink-900 leading-tight">
                  Designed for comfort
                </p>
                <p className="mt-1.5 text-xs text-ink-400 leading-relaxed">
                  Every tool serves the patient experience.
                </p>
              </div>
            </div>
          </Reveal>
        </div>
      </Container>
    </section>
  );
}
