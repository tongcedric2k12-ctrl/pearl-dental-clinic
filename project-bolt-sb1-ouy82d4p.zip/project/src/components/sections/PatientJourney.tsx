import { journeySteps } from '@/data/site';
import { Container } from '@/components/ui/Container';
import { SectionHeading } from '@/components/ui/SectionHeading';
import { Reveal } from '@/components/ui/Reveal';

export function PatientJourney() {
  return (
    <section className="section-py bg-navy-950 text-stone-100">
      <Container>
        <SectionHeading
          eyebrow="Your Visit"
          title="Your visit, made simple."
          description="A clear, straightforward process designed to reduce uncertainty and make getting started easy."
          align="center"
          className="mb-14 lg:mb-20"
        />

        <div className="relative">
          <div
            className="absolute left-0 right-0 top-7 hidden lg:block h-px bg-gradient-to-r from-transparent via-navy-800 to-transparent"
            aria-hidden="true"
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-6">
            {journeySteps.map((step, index) => {
              const Icon = step.icon;
              return (
                <Reveal key={step.number} delay={index * 100}>
                  <div className="relative flex flex-col items-start gap-4 lg:items-center lg:text-center">
                    <div className="relative z-10 flex h-14 w-14 items-center justify-center rounded-full bg-navy-800 border border-navy-700 text-stone-200">
                      <Icon className="h-5 w-5" strokeWidth={1.5} />
                      <span className="absolute -top-2 -right-2 flex h-6 w-6 items-center justify-center rounded-full bg-accent-500 text-[0.625rem] font-semibold text-stone-50">
                        {step.number}
                      </span>
                    </div>
                    <h3 className="text-lg font-medium text-stone-50 mt-1">
                      {step.title}
                    </h3>
                    <p className="text-sm leading-relaxed text-stone-300 max-w-xs text-pretty lg:mx-auto">
                      {step.description}
                    </p>
                  </div>
                </Reveal>
              );
            })}
          </div>
        </div>
      </Container>
    </section>
  );
}
