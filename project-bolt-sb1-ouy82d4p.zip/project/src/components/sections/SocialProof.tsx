import { reviews } from '@/data/site';
import { Container } from '@/components/ui/Container';
import { SectionHeading } from '@/components/ui/SectionHeading';
import { Reveal } from '@/components/ui/Reveal';
import { Star, ExternalLink } from 'lucide-react';

export function SocialProof() {
  const hasRating = reviews.googleRating !== null;
  const hasCount = reviews.reviewCount !== null;
  const hasReviews = hasRating && hasCount;

  if (hasReviews) {
    const rounded = Math.round(reviews.googleRating!);
    return (
      <section className="section-py bg-navy-950 text-stone-100">
        <Container>
          <Reveal>
            <div className="flex flex-col items-center gap-8 text-center">
              <div
                className="flex items-center gap-3"
                aria-label={`Rated ${reviews.googleRating!.toFixed(1)} out of 5`}
              >
                <div className="flex gap-0.5" aria-hidden="true">
                  {[0, 1, 2, 3, 4].map((i) => (
                    <Star
                      key={i}
                      className={`h-6 w-6 ${
                        i < rounded
                          ? 'fill-accent-400 text-accent-400'
                          : 'text-navy-700'
                      }`}
                    />
                  ))}
                </div>
                <span className="font-serif text-3xl text-stone-50">
                  {reviews.googleRating!.toFixed(1)}
                </span>
              </div>
              <p className="text-sm text-stone-300 max-w-md text-pretty">
                Based on {reviews.reviewCount} verified Google reviews from
                our patients.
              </p>
              {reviews.googleReviewsUrl && (
                <a
                  href={reviews.googleReviewsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-sm font-medium text-stone-200 hover:text-stone-50 transition-colors link-underline"
                >
                  Read reviews on Google
                  <ExternalLink className="h-3.5 w-3.5" />
                </a>
              )}
            </div>
          </Reveal>
        </Container>
      </section>
    );
  }

  return (
    <section className="section-py bg-navy-950 text-stone-100">
      <Container>
        <SectionHeading
          eyebrow="Verified Patient Feedback"
          title="Real reviews from real patients."
          description="Verified Google reviews will be displayed here once the clinic's review profile is connected."
          align="center"
          className="mb-14 lg:mb-20"
        />

        <Reveal>
          <div className="mx-auto max-w-2xl rounded-lg border border-navy-800/60 bg-navy-900/30 px-8 py-12 text-center">
            <div className="flex justify-center gap-1 mb-5" aria-hidden="true">
              {[0, 1, 2, 3, 4].map((i) => (
                <Star
                  key={i}
                  className="h-5 w-5 text-navy-700"
                />
              ))}
            </div>
            <p className="font-serif text-xl text-stone-200 leading-relaxed text-balance">
              Patient reviews will appear here.
            </p>
            <p className="mt-3 text-sm text-stone-400 leading-relaxed text-pretty">
              Verified Google reviews will be connected during implementation,
              displaying real ratings, review counts and individual patient
              feedback.
            </p>
          </div>
        </Reveal>

        <p className="mt-8 text-xs text-stone-500 text-center max-w-xl mx-auto">
          Patient reviews will be connected once the clinic&apos;s Google Business Profile is verified.
        </p>
      </Container>
    </section>
  );
}
