import { useState, useRef, useCallback, useEffect } from 'react';
import { galleryItems } from '@/data/site';
import { Container } from '@/components/ui/Container';
import { SectionHeading } from '@/components/ui/SectionHeading';
import { Reveal } from '@/components/ui/Reveal';

export function BeforeAfterGallery() {
  return (
    <section className="section-py bg-stone-100">
      <Container>
        <SectionHeading
          eyebrow="Smile Transformations"
          title="A closer look at what's possible."
          description="Explore treatment outcomes with our interactive before-and-after comparison."
          className="mb-4"
        />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 lg:gap-8">
          {galleryItems.map((item, index) => (
            <Reveal key={item.id} delay={index * 100}>
              <BeforeAfterCard
                before={item.before}
                after={item.after}
                category={item.category}
              />
            </Reveal>
          ))}
        </div>


      </Container>
    </section>
  );
}

function BeforeAfterCard({
  before,
  after,
  category,
}: {
  before: string;
  after: string;
  category: string;
}) {
  const [position, setPosition] = useState(50);
  const [containerWidth, setContainerWidth] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const update = () => setContainerWidth(el.clientWidth);
    update();
    const observer = new ResizeObserver(update);
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  const handleMove = useCallback((clientX: number) => {
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return;
    const pct = ((clientX - rect.left) / rect.width) * 100;
    setPosition(Math.max(0, Math.min(100, pct)));
  }, []);

  const handleKey = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowLeft') {
      e.preventDefault();
      setPosition((p) => Math.max(0, p - 5));
    } else if (e.key === 'ArrowRight') {
      e.preventDefault();
      setPosition((p) => Math.min(100, p + 5));
    } else if (e.key === 'Home') {
      e.preventDefault();
      setPosition(0);
    } else if (e.key === 'End') {
      e.preventDefault();
      setPosition(100);
    }
  };

  return (
    <div>
      <div
        ref={containerRef}
        className="relative aspect-[4/3] overflow-hidden rounded-lg select-none cursor-ew-resize bg-ink-100"
        onMouseMove={(e) => {
          if (e.buttons === 1) handleMove(e.clientX);
        }}
        onTouchMove={(e) => handleMove(e.touches[0].clientX)}
        onClick={(e) => handleMove(e.clientX)}
        onKeyDown={handleKey}
        tabIndex={0}
        role="slider"
        aria-valuenow={Math.round(position)}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-label={`${category} before and after comparison. Use left and right arrow keys to adjust.`}
      >
        <img
          src={after}
          alt={`${category} after treatment`}
          loading="lazy"
          className="absolute inset-0 h-full w-full object-cover"
        />
        <span className="absolute top-3 right-3 bg-stone-50/90 text-[0.625rem] font-semibold uppercase tracking-[0.12em] px-2.5 py-1 text-navy-700 rounded">
          After
        </span>

        <div
          className="absolute inset-0 overflow-hidden"
          style={{ width: `${position}%` }}
        >
          <img
            src={before}
            alt={`${category} before treatment`}
            loading="lazy"
            className="absolute inset-0 h-full object-cover"
            style={{ width: containerWidth || '100%' }}
          />
          <span className="absolute top-3 left-3 bg-stone-50/90 text-[0.625rem] font-semibold uppercase tracking-[0.12em] px-2.5 py-1 text-navy-700 rounded">
            Before
          </span>
        </div>

        <div
          className="absolute top-0 bottom-0 w-0.5 bg-stone-50 pointer-events-none"
          style={{ left: `${position}%` }}
        >
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-8 w-8 rounded-full bg-stone-50 shadow-md flex items-center justify-center">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-ink-700">
              <path d="M8 7l-5 5 5 5M16 7l5 5-5 5" />
            </svg>
          </div>
        </div>
      </div>
      <p className="mt-3 text-sm font-medium text-ink-700">{category}</p>
    </div>
  );
}
