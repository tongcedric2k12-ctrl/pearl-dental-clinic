import { useState, useEffect } from 'react';
import { treatments, type Treatment } from '@/data/site';
import { Container } from '@/components/ui/Container';
import { SectionHeading } from '@/components/ui/SectionHeading';
import { Reveal } from '@/components/ui/Reveal';
import { Button } from '@/components/ui/Button';
import { ArrowRight, X } from 'lucide-react';

export function TreatmentGrid() {
  const [selected, setSelected] = useState<Treatment | null>(null);

  return (
    <section id="treatments" className="section-py bg-stone-100">
      <Container>
        <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between mb-14 lg:mb-20">
          <SectionHeading
            eyebrow="Treatments"
            title="Comprehensive dental care, thoughtfully delivered."
            description="From routine check-ups to cosmetic and restorative treatment, explore the range of services available."
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {treatments.map((treatment, index) => (
            <Reveal key={treatment.id} delay={(index % 4) * 80}>
              <TreatmentCard
                treatment={treatment}
                onClick={() => setSelected(treatment)}
              />
            </Reveal>
          ))}
        </div>
      </Container>

      {selected && (
        <TreatmentModal
          treatment={selected}
          onClose={() => setSelected(null)}
        />
      )}
    </section>
  );
}

function TreatmentCard({
  treatment,
  onClick,
}: {
  treatment: Treatment;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="group flex flex-col text-left bg-stone-50 border border-ink-100 overflow-hidden transition-all duration-300 ease-smooth hover:shadow-lg hover:border-navy-200 rounded-lg w-full"
      aria-label={`Learn more about ${treatment.name}`}
    >
      <div className="relative aspect-[4/3] overflow-hidden">
        <img
          src={treatment.image}
          alt={treatment.name}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-500 ease-smooth group-hover:scale-[1.04]"
        />
        <span className="absolute top-3 left-3 bg-stone-50/90 backdrop-blur-sm text-[0.625rem] font-medium uppercase tracking-[0.12em] px-2.5 py-1 text-navy-700 rounded">
          {treatment.category}
        </span>
      </div>
      <div className="flex flex-col gap-3 p-5 flex-1">
        <h3 className="text-base font-medium text-ink-900">
          {treatment.name}
        </h3>
        <p className="text-sm leading-relaxed text-ink-500 line-clamp-3 flex-1">
          {treatment.shortDescription}
        </p>
        <span className="inline-flex items-center gap-1.5 text-sm font-medium text-navy-700 transition-colors group-hover:text-navy-900 mt-1">
          Learn More
          <ArrowRight className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-1" />
        </span>
      </div>
    </button>
  );
}

function TreatmentModal({
  treatment,
  onClose,
}: {
  treatment: Treatment;
  onClose: () => void;
}) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center"
      role="dialog"
      aria-modal="true"
      aria-labelledby="treatment-modal-title"
    >
      <div
        className="absolute inset-0 bg-ink-950/50 backdrop-blur-sm animate-fade-in"
        onClick={onClose}
        aria-hidden="true"
      />

      <div className="relative z-10 w-full sm:max-w-2xl max-h-[90svh] overflow-y-auto bg-stone-50 rounded-t-2xl sm:rounded-2xl shadow-2xl animate-fade-up">
        <div className="relative">
          <img
            src={treatment.image}
            alt={treatment.name}
            className="h-48 sm:h-56 w-full object-cover rounded-t-2xl"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-ink-950/60 to-transparent rounded-t-2xl" />
          <button
            onClick={onClose}
            aria-label="Close"
            className="absolute top-4 right-4 flex h-9 w-9 items-center justify-center rounded-full bg-stone-50/90 text-ink-700 hover:bg-stone-50 transition-colors"
          >
            <X className="h-4.5 w-4.5" />
          </button>
          <span className="absolute bottom-4 left-5 bg-stone-50/90 backdrop-blur-sm text-[0.625rem] font-medium uppercase tracking-[0.12em] px-2.5 py-1 text-navy-700 rounded">
            {treatment.category}
          </span>
        </div>

        <div className="p-6 sm:p-8">
          <h3
            id="treatment-modal-title"
            className="font-serif text-2xl sm:text-3xl text-ink-900"
          >
            {treatment.name}
          </h3>

          <div className="mt-6 space-y-6">
            <div>
              <h4 className="text-xs font-semibold uppercase tracking-[0.16em] text-ink-400 mb-2">
                Overview
              </h4>
              <p className="text-sm leading-relaxed text-ink-600">
                {treatment.overview}
              </p>
            </div>

            <div>
              <h4 className="text-xs font-semibold uppercase tracking-[0.16em] text-ink-400 mb-2">
                Who it may suit
              </h4>
              <p className="text-sm leading-relaxed text-ink-600">
                {treatment.whoItSuits}
              </p>
            </div>

            <div>
              <h4 className="text-xs font-semibold uppercase tracking-[0.16em] text-ink-400 mb-3">
                What the process may involve
              </h4>
              <ol className="space-y-2.5">
                {treatment.process.map((step, i) => (
                  <li
                    key={i}
                    className="flex gap-3 text-sm leading-relaxed text-ink-600"
                  >
                    <span className="font-serif text-accent-400 shrink-0">
                      {String(i + 1).padStart(2, '0')}
                    </span>
                    <span>{step}</span>
                  </li>
                ))}
              </ol>
            </div>

            <div>
              <h4 className="text-xs font-semibold uppercase tracking-[0.16em] text-ink-400 mb-2">
                Key considerations
              </h4>
              <p className="text-sm leading-relaxed text-ink-600">
                {treatment.considerations}
              </p>
            </div>
          </div>

          <div className="mt-8 flex flex-col sm:flex-row gap-3">
            <Button href="#booking" size="md" icon onClick={onClose} className="w-full sm:w-auto">
              Book an Appointment
            </Button>
            <Button variant="secondary" size="md" onClick={onClose} className="w-full sm:w-auto">
              Close
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
