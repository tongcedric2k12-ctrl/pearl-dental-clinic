import { images, heroTrustIndicators, clinicInfo } from '@/data/site';
import { Button } from '@/components/ui/Button';
import { ShieldCheck, ChevronDown } from 'lucide-react';

export function Hero() {
  return (
    <section
      id="home"
      className="relative min-h-[100svh] flex items-end overflow-hidden bg-navy-950"
    >
      <div className="absolute inset-0">
        <img
          src={images.hero}
          alt="Patient receiving treatment at a modern dental clinic with natural lighting"
          className="h-full w-full object-cover"
          fetchPriority="high"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-navy-950/92 via-navy-950/45 to-navy-950/20" />
        <div className="absolute inset-0 bg-gradient-to-r from-navy-950/70 via-navy-950/10 to-transparent" />
      </div>

      <div className="relative z-10 w-full pb-16 pt-32 lg:pb-24 lg:pt-40">
        <div className="mx-auto max-w-content container-px">
          <div className="max-w-2xl">
            <span className="eyebrow text-stone-300/90 animate-fade-up" style={{ letterSpacing: '0.2em' }}>
              {clinicInfo.city} Dental Studio
            </span>

            <h1
              className="mt-6 font-serif text-4xl sm:text-5xl lg:text-display-lg leading-[1.02] text-stone-50 text-balance animate-fade-up"
              style={{ animationDelay: '80ms' }}
            >
              Confident smiles.
              <br />
              Exceptional dental care.
            </h1>

            <p
              className="mt-7 text-base lg:text-lg leading-relaxed text-stone-200 max-w-xl text-pretty animate-fade-up"
              style={{ animationDelay: '160ms' }}
            >
              Personalised dentistry combining modern technology, thoughtful
              treatment and a genuinely comfortable patient experience.
            </p>

            <div
              className="mt-9 flex flex-col sm:flex-row gap-3 sm:items-center animate-fade-up"
              style={{ animationDelay: '240ms' }}
            >
              <Button href={clinicInfo.bookingUrl} size="lg" icon>
                Book an Appointment
              </Button>
              <Button href="#treatments" variant="secondary" size="lg">
                Explore Treatments
              </Button>
            </div>

            <p
              className="mt-6 flex items-center gap-2 text-sm text-stone-300/80 animate-fade-up"
              style={{ animationDelay: '320ms' }}
            >
              <ShieldCheck className="h-4 w-4 text-stone-400 shrink-0" />
              Appointment requests are reviewed by our team.
            </p>

            <div
              className="mt-12 flex flex-wrap gap-x-8 gap-y-4 border-t border-stone-50/15 pt-6 animate-fade-up"
              style={{ animationDelay: '440ms' }}
            >
              {heroTrustIndicators.map((indicator) => (
                <div
                  key={indicator}
                  className="flex items-center gap-2.5"
                >
                  <span className="h-1.5 w-1.5 rounded-full bg-accent-400" />
                  <span className="text-xs font-medium uppercase tracking-[0.14em] text-stone-200">
                    {indicator}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <a
        href="#treatments"
        aria-label="Scroll to treatments"
        className="absolute bottom-6 left-1/2 -translate-x-1/2 z-10 hidden lg:flex flex-col items-center gap-1 text-stone-300/60 hover:text-stone-200 transition-colors"
      >
        <span className="text-[0.625rem] font-medium uppercase tracking-[0.2em]">Scroll</span>
        <ChevronDown className="h-4 w-4 animate-bounce" />
      </a>
    </section>
  );
}
