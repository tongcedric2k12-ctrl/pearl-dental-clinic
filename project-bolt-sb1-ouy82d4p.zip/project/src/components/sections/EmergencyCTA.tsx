import { clinicInfo } from '@/data/site';
import { Container } from '@/components/ui/Container';
import { Button } from '@/components/ui/Button';
import { Reveal } from '@/components/ui/Reveal';
import { Phone } from 'lucide-react';

export function EmergencyCTA() {
  return (
    <section className="py-20 lg:py-24 bg-stone-100">
      <Container>
        <Reveal>
          <div className="relative overflow-hidden rounded-2xl bg-navy-900 px-6 py-12 sm:px-12 lg:px-16 lg:py-16">
            <div aria-hidden="true" className="absolute top-0 right-0 h-full w-1/3 bg-gradient-to-l from-navy-800/40 to-transparent pointer-events-none" />

            <div className="relative z-10 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-8">
              <div className="max-w-xl">
                <span className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.16em] text-accent-300">
                  <span className="h-1.5 w-1.5 rounded-full bg-accent-400" />
                  Emergency Dentistry
                </span>
                <h2 className="mt-5 font-serif text-3xl sm:text-4xl leading-[1.1] text-stone-50 text-balance">
                  Need urgent dental care?
                </h2>
                <p className="mt-4 text-stone-300 leading-relaxed text-pretty">
                  If you're experiencing a dental emergency, contact the clinic
                  to discuss the next available appointment.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-3 shrink-0">
                <Button
                  href={clinicInfo.phoneHref}
                  size="lg"
                  className="w-full sm:w-auto"
                >
                  <Phone className="h-4 w-4" />
                  Call the Clinic
                </Button>
                <Button
                  href="#contact"
                  variant="secondary"
                  size="lg"
                  className="w-full sm:w-auto"
                >
                  Contact Us
                </Button>
              </div>
            </div>
          </div>
        </Reveal>
      </Container>
    </section>
  );
}
