import { valuePillars } from '@/data/site';
import { Container } from '@/components/ui/Container';
import { Reveal } from '@/components/ui/Reveal';
import { Button } from '@/components/ui/Button';

export function WhyUs() {
  return (
    <section id="why-us" className="section-py bg-navy-950 text-stone-100">
      <Container>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16">
          <div className="lg:col-span-5">
            <Reveal>
              <span className="eyebrow text-stone-400">Why Choose Us</span>
              <h2 className="mt-5 font-serif text-3xl sm:text-4xl lg:text-[2.75rem] leading-[1.1] text-stone-50 text-balance">
                A better dental experience, from the first visit.
              </h2>
              <p className="mt-6 text-stone-300 leading-relaxed max-w-md text-pretty">
                Dental care should feel considered, clear and comfortable — not rushed or clinical. Every detail of our practice is designed around that principle.
              </p>
              <div className="mt-8 hidden lg:block">
                <Button href="#booking" variant="secondary" size="md" icon>
                  Book a Consultation
                </Button>
              </div>
            </Reveal>
          </div>

          <div className="lg:col-span-7">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-px bg-navy-800/40 rounded-lg overflow-hidden">
              {valuePillars.map((pillar, index) => {
                const Icon = pillar.icon;
                return (
                  <Reveal key={pillar.number} delay={index * 80}>
                    <div className="bg-navy-950 p-6 lg:p-8 h-full">
                      <div className="flex items-center justify-between mb-5">
                        <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-navy-800/60 text-accent-400">
                          <Icon className="h-5 w-5" strokeWidth={1.5} />
                        </div>
                        <span className="font-serif text-2xl text-navy-700">
                          {pillar.number}
                        </span>
                      </div>
                      <h3 className="text-base font-medium text-stone-50">
                        {pillar.title}
                      </h3>
                      <p className="mt-2.5 text-sm leading-relaxed text-stone-300 text-pretty">
                        {pillar.description}
                      </p>
                    </div>
                  </Reveal>
                );
              })}
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}
