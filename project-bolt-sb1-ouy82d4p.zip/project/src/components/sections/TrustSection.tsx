import { trustStrip } from '@/data/site';
import { Container } from '@/components/ui/Container';

export function TrustSection() {
  return (
    <section className="border-b border-ink-100 bg-stone-50">
      <Container>
        <ul className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-y-3 sm:gap-4 py-7 lg:py-9">
          {trustStrip.map((item, index) => (
            <li
              key={item}
              className="flex items-center gap-3 text-sm text-ink-600"
            >
              <span className="flex h-5 w-5 items-center justify-center rounded-full bg-navy-50 shrink-0">
                <span className="h-1.5 w-1.5 rounded-full bg-accent-400" />
              </span>
              <span className="font-medium">{item}</span>
              {index < trustStrip.length - 1 && (
                <span className="hidden sm:block w-px h-4 bg-ink-100 ml-3" aria-hidden="true" />
              )}
            </li>
          ))}
        </ul>
      </Container>
    </section>
  );
}
