import { useState } from 'react';
import { faqItems } from '@/data/site';
import { Container } from '@/components/ui/Container';
import { SectionHeading } from '@/components/ui/SectionHeading';
import { Reveal } from '@/components/ui/Reveal';
import { Plus } from 'lucide-react';

export function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section className="section-py bg-stone-50">
      <Container>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16">
          <div className="lg:col-span-4">
            <Reveal>
              <SectionHeading
                eyebrow="FAQ"
                title="Common questions."
                description="Everything you need to know before your visit. Can't find what you're looking for? Contact our team."
              />
              <div className="mt-6">
                <a
                  href="#contact"
                  className="inline-flex items-center gap-1.5 text-sm font-medium text-navy-700 hover:text-navy-900 link-underline"
                >
                  Contact the clinic
                </a>
              </div>
            </Reveal>
          </div>

          <div className="lg:col-span-8">
            <div className="flex flex-col">
              {faqItems.map((item, index) => {
                const isOpen = openIndex === index;
                const panelId = `faq-panel-${index}`;
                const buttonId = `faq-button-${index}`;
                return (
                  <Reveal key={index} delay={index * 50}>
                    <div
                      className={`border-b border-ink-100 ${
                        index === 0 ? 'border-t' : ''
                      }`}
                    >
                      <h3>
                        <button
                          id={buttonId}
                          onClick={() => setOpenIndex(isOpen ? null : index)}
                          className="flex w-full items-center justify-between gap-4 py-5 text-left"
                          aria-expanded={isOpen}
                          aria-controls={panelId}
                        >
                          <span className="text-base font-medium text-ink-900">
                            {item.question}
                          </span>
                          <Plus
                            className={`h-5 w-5 text-ink-400 shrink-0 transition-transform duration-300 ${
                              isOpen ? 'rotate-45' : ''
                            }`}
                          />
                        </button>
                      </h3>
                      <div
                        id={panelId}
                        role="region"
                        aria-labelledby={buttonId}
                        className="grid transition-all duration-300 ease-smooth"
                        style={{
                          gridTemplateRows: isOpen ? '1fr' : '0fr',
                        }}
                      >
                        <div className="overflow-hidden">
                          <p className="pb-5 text-sm leading-relaxed text-ink-500 text-pretty pr-8">
                            {item.answer}
                          </p>
                        </div>
                      </div>
                    </div>
                  </Reveal>
                );
              })}
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}
