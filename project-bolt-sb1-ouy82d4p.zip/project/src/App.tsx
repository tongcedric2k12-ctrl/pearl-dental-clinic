import { Navbar } from '@/components/layout/Navbar';
import { Footer } from '@/components/layout/Footer';
import { MobileStickyCTA } from '@/components/layout/MobileStickyCTA';
import { Hero } from '@/components/sections/Hero';
import { TrustSection } from '@/components/sections/TrustSection';
import { TreatmentGrid } from '@/components/sections/TreatmentGrid';
import { FeaturedTreatment } from '@/components/sections/FeaturedTreatment';
import { WhyUs } from '@/components/sections/WhyUs';
import { TechnologySection } from '@/components/sections/TechnologySection';
import { PatientJourney } from '@/components/sections/PatientJourney';
import { AboutSection } from '@/components/sections/AboutSection';
import { TeamSection } from '@/components/sections/TeamSection';
import { PatientExperience } from '@/components/sections/PatientExperience';
import { BeforeAfterGallery } from '@/components/sections/BeforeAfterGallery';
import { SocialProof } from '@/components/sections/SocialProof';
import { EmergencyCTA } from '@/components/sections/EmergencyCTA';
import { FAQ } from '@/components/sections/FAQ';
import { BookingSection } from '@/components/sections/BookingSection';
import { ContactSection } from '@/components/sections/ContactSection';

function App() {
  return (
    <div className="min-h-screen bg-stone-50">
      <Navbar />

      <main>
        <Hero />
        <TrustSection />
        <TreatmentGrid />
        <FeaturedTreatment />
        <WhyUs />
        <TechnologySection />
        <PatientJourney />
        <AboutSection />
        <TeamSection />
        <PatientExperience />
        <BeforeAfterGallery />
        <SocialProof />
        <EmergencyCTA />
        <FAQ />
        <BookingSection />
        <ContactSection />
      </main>

      <Footer />
      <MobileStickyCTA />

      <div className="h-14 lg:hidden" aria-hidden="true" />
    </div>
  );
}

export default App;
