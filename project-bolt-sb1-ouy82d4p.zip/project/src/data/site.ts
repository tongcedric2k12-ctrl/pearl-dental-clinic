import type { LucideIcon } from 'lucide-react';
import {
  HeartPulse,
  Scan,
  MessageSquareText,
  CalendarCheck,
  Users,
  ListChecks,
  Sun,
  ArrowRight,
} from 'lucide-react';

// ─── Types ──────────────────────────────────────────────

export interface NavItem {
  label: string;
  href: string;
}

export interface ValuePillar {
  number: string;
  title: string;
  description: string;
  icon: LucideIcon;
}

export interface Treatment {
  id: string;
  name: string;
  category: string;
  shortDescription: string;
  image: string;
  overview: string;
  whoItSuits: string;
  process: string[];
  considerations: string;
}

export interface TeamMember {
  id: string;
  name: string;
  role: string;
  bio: string;
  areas: string[];
  image: string;
}

export interface FaqItem {
  question: string;
  answer: string;
}

export interface JourneyStep {
  number: string;
  title: string;
  description: string;
  icon: LucideIcon;
}

export interface GalleryItem {
  id: string;
  category: string;
  before: string;
  after: string;
}

export interface ReviewData {
  googleRating: number | null;
  reviewCount: number | null;
  googleReviewsUrl: string;
}

// ─── Clinic Information ──────────────────────────────────

export const clinicInfo = {
  clinicName: 'Northstar Dental Studio',
  tagline: 'Modern dentistry. Exceptional care.',
  city: 'Sydney',
  region: 'NSW',
  country: 'Australia',
  address: '[Clinic address — replace with your practice address]',
  phone: '[Phone number]',
  phoneHref: 'tel:+61200000000',
  email: '[Email address]',
  emailHref: 'mailto:hello@northstardentalstudio.com.au',
  bookingUrl: '#booking',
  mapsUrl: 'https://maps.google.com',
  openingHours: [
    { day: 'Monday', hours: '8:00 AM – 6:00 PM' },
    { day: 'Tuesday', hours: '8:00 AM – 6:00 PM' },
    { day: 'Wednesday', hours: '8:00 AM – 6:00 PM' },
    { day: 'Thursday', hours: '8:00 AM – 6:00 PM' },
    { day: 'Friday', hours: '8:00 AM – 4:00 PM' },
    { day: 'Saturday', hours: 'By appointment' },
    { day: 'Sunday', hours: 'Closed' },
  ],
};

// ─── Branding ────────────────────────────────────────────

export const branding = {
  primaryColor: '#1c3042',
  secondaryColor: '#27272f',
  accentColor: '#cf844a',
  logoText: 'Northstar',
  logoSubtext: 'Dental Studio',
  favicon: '/favicon.svg',
};

// ─── Google Reviews ──────────────────────────────────────

export const reviews: ReviewData = {
  googleRating: null,
  reviewCount: null,
  googleReviewsUrl: '',
};

// ─── SEO ─────────────────────────────────────────────────

export const seo = {
  title: 'Northstar Dental Studio | Modern Dental Care in Sydney',
  description:
    'Northstar Dental Studio provides personalised modern dental care, cosmetic dentistry, Invisalign, implants and general dental services in Sydney.',
  ogImage:
    'https://images.pexels.com/photos/6627574/pexels-photo-6627574.jpeg?auto=compress&cs=tinysrgb&w=1200&h=630&fit=crop',
  canonical: 'https://www.northstardentalstudio.com.au/',
};

// ─── Navigation ──────────────────────────────────────────

export const navigation: NavItem[] = [
  { label: 'Treatments', href: '#treatments' },
  { label: 'Why Us', href: '#why-us' },
  { label: 'About', href: '#about' },
  { label: 'Our Team', href: '#team' },
  { label: 'Experience', href: '#experience' },
  { label: 'Contact', href: '#contact' },
];

// ─── Images ──────────────────────────────────────────────

export const images = {
  hero: 'https://images.pexels.com/photos/6627574/pexels-photo-6627574.jpeg?auto=compress&cs=tinysrgb&w=1600&h=1100&fit=crop',
  clinicInterior:
    'https://images.pexels.com/photos/6812434/pexels-photo-6812434.jpeg?auto=compress&cs=tinysrgb&w=1200&h=800&fit=crop',
  consultation:
    'https://images.pexels.com/photos/5355693/pexels-photo-5355693.jpeg?auto=compress&cs=tinysrgb&w=1200&h=800&fit=crop',
  treatmentRoom:
    'https://images.pexels.com/photos/6812463/pexels-photo-6812463.jpeg?auto=compress&cs=tinysrgb&w=1200&h=800&fit=crop',
  cosmetic:
    'https://images.pexels.com/photos/6627571/pexels-photo-6627571.jpeg?auto=compress&cs=tinysrgb&w=1200&h=900&fit=crop',
  team: 'https://images.pexels.com/photos/3952136/pexels-photo-3952136.jpeg?auto=compress&cs=tinysrgb&w=1200&h=800&fit=crop',
  aboutMain:
    'https://images.pexels.com/photos/4270093/pexels-photo-4270093.jpeg?auto=compress&cs=tinysrgb&w=1000&h=1250&fit=crop',
  aboutSecondary:
    'https://images.pexels.com/photos/6812429/pexels-photo-6812429.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
  experienceReception:
    'https://images.pexels.com/photos/6812436/pexels-photo-6812436.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
  experienceConsultation:
    'https://images.pexels.com/photos/5355693/pexels-photo-5355693.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
  experienceTreatment:
    'https://images.pexels.com/photos/5355920/pexels-photo-5355920.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
  experienceInteraction:
    'https://images.pexels.com/photos/3952125/pexels-photo-3952125.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
  beforeAfterWhiteningBefore:
    'https://images.pexels.com/photos/12474261/pexels-photo-12474261.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
  beforeAfterWhiteningAfter:
    'https://images.pexels.com/photos/3762402/pexels-photo-3762402.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
  beforeAfterCosmeticBefore:
    'https://images.pexels.com/photos/16212691.png?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
  beforeAfterCosmeticAfter:
    'https://images.pexels.com/photos/6627574/pexels-photo-6627574.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
  beforeAfterSmileBefore:
    'https://images.pexels.com/photos/6627572/pexels-photo-6627572.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
  beforeAfterSmileAfter:
    'https://images.pexels.com/photos/6627571/pexels-photo-6627571.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
};

// ─── Hero Trust Indicators ───────────────────────────────

export const heroTrustIndicators = [
  'Modern Technology',
  'Personalised Care',
  'Comfortable Experience',
];

// ─── Trust Strip ─────────────────────────────────────────

export const trustStrip = [
  'Personalised treatment planning',
  'Modern digital technology',
  'Clear, upfront communication',
  'Calm, welcoming environment',
];

// ─── Value Pillars ───────────────────────────────────────

export const valuePillars: ValuePillar[] = [
  {
    number: '01',
    title: 'Personalised Care',
    description:
      'Every treatment plan starts with understanding you — your needs, goals and comfort. No two plans are the same.',
    icon: HeartPulse,
  },
  {
    number: '02',
    title: 'Modern Approach',
    description:
      'Digital scanning, 3D imaging and treatment planning software support thorough, efficient and comfortable care.',
    icon: Scan,
  },
  {
    number: '03',
    title: 'Calm Environment',
    description:
      'A welcoming space designed to make visits feel easier — from the reception to the treatment chair.',
    icon: Sun,
  },
  {
    number: '04',
    title: 'Clear Communication',
    description:
      'Honest guidance and straightforward explanations, so you can make informed decisions about your care.',
    icon: MessageSquareText,
  },
];

// ─── Treatments ──────────────────────────────────────────

export const treatments: Treatment[] = [
  {
    id: 'general',
    name: 'General Dentistry',
    category: 'Essential Care',
    shortDescription:
      'Routine check-ups, examinations and restorative care to maintain long-term oral health.',
    image:
      'https://images.pexels.com/photos/8413334/pexels-photo-8413334.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    overview:
      'General dentistry is the foundation of oral health — routine examinations, professional cleaning, fillings and restorative treatment. Regular visits help identify concerns early and keep teeth and gums healthy.',
    whoItSuits:
      'Suitable for all patients seeking routine preventive and restorative dental care.',
    process: [
      'Comprehensive dental examination',
      'Professional cleaning and assessment',
      'Discussion of any concerns or goals',
      'Tailored treatment planning if required',
    ],
    considerations:
      'Treatment costs vary depending on individual needs and treatment planning.',
  },
  {
    id: 'cosmetic',
    name: 'Cosmetic Dentistry',
    category: 'Aesthetic',
    shortDescription:
      'Treatments designed to enhance the appearance of your smile, including veneers and smile planning.',
    image:
      'https://images.pexels.com/photos/6627571/pexels-photo-6627571.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    overview:
      'Cosmetic dentistry focuses on the appearance of teeth, gums and the overall smile. Options may include veneers, bonding and comprehensive smile planning — tailored to facial features and individual goals.',
    whoItSuits:
      'Patients looking to enhance the appearance of their smile through considered aesthetic treatment.',
    process: [
      'Initial consultation and smile assessment',
      'Discussion of aesthetic goals and options',
      'Custom treatment planning',
      'Staged treatment with review at each step',
    ],
    considerations:
      'Treatment costs vary depending on individual needs. Outcomes depend on individual circumstances.',
  },
  {
    id: 'invisalign',
    name: 'Invisalign',
    category: 'Orthodontic',
    shortDescription:
      'Clear aligner treatment designed to discreetly straighten teeth over time.',
    image:
      'https://images.pexels.com/photos/3762402/pexels-photo-3762402.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    overview:
      'Invisalign uses a series of custom-made clear aligners to gradually guide teeth into their desired position. The aligners are removable and designed to be discreet — a popular option for adults and teens.',
    whoItSuits:
      'Patients seeking a discreet alternative to traditional braces for mild to moderate alignment concerns.',
    process: [
      'Consultation and suitability assessment',
      'Digital treatment planning',
      'Custom aligner production',
      'Regular progress reviews and refinements',
    ],
    considerations:
      'Treatment duration and suitability vary. Costs depend on individual needs and treatment planning.',
  },
  {
    id: 'implants',
    name: 'Dental Implants',
    category: 'Restorative',
    shortDescription:
      'A tooth replacement option designed to restore function and appearance.',
    image:
      'https://images.pexels.com/photos/6812463/pexels-photo-6812463.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    overview:
      'Dental implants provide a fixed solution for replacing missing teeth. A titanium post is placed in the jaw, and a custom crown is attached to restore appearance and function. The process is staged over several months to allow for healing.',
    whoItSuits:
      'Patients with missing teeth seeking a long-term replacement option with suitable bone structure.',
    process: [
      'Assessment and treatment planning',
      'Implant placement',
      'Healing and integration period',
      'Custom crown fitting and review',
    ],
    considerations:
      'Suitability depends on individual clinical assessment. Costs vary depending on individual needs.',
  },
  {
    id: 'whitening',
    name: 'Teeth Whitening',
    category: 'Aesthetic',
    shortDescription:
      'Professional whitening treatment to brighten and refresh your smile.',
    image:
      'https://images.pexels.com/photos/12474261/pexels-photo-12474261.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    overview:
      'Professional teeth whitening can help lighten the shade of natural teeth. Treatment may be provided in-chair or through a take-home kit with custom trays — depending on individual needs and preferences.',
    whoItSuits:
      'Patients with healthy teeth and gums looking to brighten their natural smile.',
    process: [
      'Assessment of suitability',
      'Shade assessment and planning',
      'Professional whitening treatment',
      'Aftercare guidance and maintenance',
    ],
    considerations:
      'Results vary between individuals. Not all types of discolouration respond to whitening.',
  },
  {
    id: 'emergency',
    name: 'Emergency Dentistry',
    category: 'Urgent Care',
    shortDescription:
      'Prompt attention for dental pain, trauma and other urgent concerns.',
    image:
      'https://images.pexels.com/photos/5215024/pexels-photo-5215024.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    overview:
      'Emergency dentistry addresses urgent dental concerns including severe pain, swelling, broken teeth and dental trauma. The goal is prompt assessment and relief, followed by any required ongoing treatment.',
    whoItSuits:
      'Patients experiencing dental pain, trauma or other urgent oral health concerns.',
    process: [
      'Contact the clinic to discuss your situation',
      'Prompt assessment appointment',
      'Immediate relief and stabilisation',
      'Follow-up treatment planning if needed',
    ],
    considerations:
      'If you are experiencing a dental emergency, contact the clinic to discuss the next available appointment.',
  },
  {
    id: 'preventive',
    name: 'Preventive Dentistry',
    category: 'Essential Care',
    shortDescription:
      'Proactive care focused on preventing issues before they develop.',
    image:
      'https://images.pexels.com/photos/4687337/pexels-photo-4687337.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    overview:
      'Preventive dentistry focuses on maintaining oral health through regular examinations, professional cleaning and patient education. The aim is to identify and address potential concerns before they develop into more complex issues.',
    whoItSuits:
      'All patients — preventive care is the foundation of long-term oral health.',
    process: [
      'Regular examination and cleaning',
      'Oral health assessment',
      'Personalised home-care guidance',
      'Ongoing monitoring and review',
    ],
    considerations:
      'Treatment costs vary depending on individual needs and treatment planning.',
  },
  {
    id: 'childrens',
    name: "Children's Dentistry",
    category: 'Family Care',
    shortDescription:
      'Gentle, age-appropriate dental care designed to help children feel at ease.',
    image:
      'https://images.pexels.com/photos/6627574/pexels-photo-6627574.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    overview:
      "Children's dentistry provides gentle, age-appropriate care in a welcoming environment. Early visits help children become familiar with the dental setting, establish good habits and allow for monitoring of developing teeth and bite.",
    whoItSuits:
      'Children of all ages, from first visits through to teenage years.',
    process: [
      'Gentle, child-friendly examination',
      'Cleaning and fluoride application if appropriate',
      'Guidance for parents on home care',
      'Ongoing monitoring as teeth develop',
    ],
    considerations:
      'Treatment costs vary depending on individual needs and treatment planning.',
  },
];

// ─── Team ────────────────────────────────────────────────

export const team: TeamMember[] = [
  {
    id: '1',
    name: 'Dr. [Name]',
    role: 'Dentist',
    bio: '[Replace with dentist biography. Describe qualifications, experience and approach to patient care.]',
    areas: ['General Dentistry', 'Cosmetic Dentistry', 'Preventive Care'],
    image:
      'https://images.pexels.com/photos/37458046/pexels-photo-37458046.jpeg?auto=compress&cs=tinysrgb&w=600&h=750&fit=crop',
  },
  {
    id: '2',
    name: 'Dr. [Name]',
    role: 'Dentist',
    bio: '[Replace with dentist biography. Describe qualifications, experience and approach to patient care.]',
    areas: ['Invisalign', 'Restorative Dentistry', 'Implants'],
    image:
      'https://images.pexels.com/photos/31043312/pexels-photo-31043312.jpeg?auto=compress&cs=tinysrgb&w=600&h=750&fit=crop',
  },
  {
    id: '3',
    name: 'Dr. [Name]',
    role: 'Dentist',
    bio: '[Replace with dentist biography. Describe qualifications, experience and approach to patient care.]',
    areas: ['Cosmetic Dentistry', 'Smile Design', 'Teeth Whitening'],
    image:
      'https://images.pexels.com/photos/19879741/pexels-photo-19879741.jpeg?auto=compress&cs=tinysrgb&w=600&h=750&fit=crop',
  },
];

// ─── Technology ──────────────────────────────────────────

export const technology = [
  {
    title: 'Digital Scanning',
    description:
      'Digital impressions capture precise 3D images of teeth and gums in minutes — a comfortable alternative to traditional moulds.',
    benefit: 'No messy impression material. A more comfortable experience.',
  },
  {
    title: 'Digital Imaging',
    description:
      'Modern imaging supports thorough assessment and treatment planning, revealing detail that may not be visible during a standard examination.',
    benefit: 'Earlier detection. More informed treatment decisions.',
  },
  {
    title: 'Treatment Planning Software',
    description:
      'Digital planning tools allow your dentist to map out treatment visually — so you can see proposed outcomes before treatment begins.',
    benefit: 'Clear understanding of what to expect before you commit.',
  },
];

// ─── Patient Journey ─────────────────────────────────────

export const journeySteps: JourneyStep[] = [
  {
    number: '01',
    title: 'Book',
    description: 'Request an appointment online or by phone at a time that suits you.',
    icon: CalendarCheck,
  },
  {
    number: '02',
    title: 'Consult',
    description: 'Meet your dentist and discuss your needs, concerns and goals in a relaxed setting.',
    icon: Users,
  },
  {
    number: '03',
    title: 'Plan',
    description: 'Receive clear information about suitable treatment options and associated costs.',
    icon: ListChecks,
  },
  {
    number: '04',
    title: 'Treat',
    description: 'Begin treatment with a plan tailored to your needs and timeline.',
    icon: ArrowRight,
  },
];

// ─── Before / After Gallery ──────────────────────────────

export const galleryItems: GalleryItem[] = [
  {
    id: '1',
    category: 'Teeth Whitening',
    before: images.beforeAfterWhiteningBefore,
    after: images.beforeAfterWhiteningAfter,
  },
  {
    id: '2',
    category: 'Cosmetic Veneers',
    before: images.beforeAfterCosmeticBefore,
    after: images.beforeAfterCosmeticAfter,
  },
  {
    id: '3',
    category: 'Smile Enhancement',
    before: images.beforeAfterSmileBefore,
    after: images.beforeAfterSmileAfter,
  },
];

// ─── FAQ ─────────────────────────────────────────────────

export const faqItems: FaqItem[] = [
  {
    question: 'How do I book an appointment?',
    answer:
      'Request an appointment through the booking form on this page, or call the clinic directly. Our team will contact you to confirm availability.',
  },
  {
    question: 'What treatments do you offer?',
    answer:
      "A full range including general dentistry, cosmetic dentistry, Invisalign, dental implants, teeth whitening, emergency dentistry, preventive care and children's dentistry.",
  },
  {
    question: 'Do you offer emergency dental appointments?',
    answer:
      'Yes. If you are experiencing a dental emergency, contact the clinic to discuss the next available appointment.',
  },
  {
    question: 'What happens during a first visit?',
    answer:
      'A first visit typically includes a comprehensive examination, discussion of your concerns and goals, and any necessary imaging. Your dentist will explain their findings and recommend next steps.',
  },
  {
    question: 'How much does treatment cost?',
    answer:
      'Treatment costs vary depending on individual needs. Following a consultation, your dentist will discuss recommended treatment and associated costs.',
  },
  {
    question: 'Do you offer payment plans?',
    answer:
      'Payment options can be discussed during your consultation. Our team will provide clear information about costs and available payment methods before any treatment begins.',
  },
];

// ─── Social Links ────────────────────────────────────────

export const socialLinks = {
  instagram: 'https://instagram.com',
  facebook: 'https://facebook.com',
};
