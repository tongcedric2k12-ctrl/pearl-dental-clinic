/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: {
          50: '#f6f6f7',
          100: '#ececed',
          200: '#d4d4d7',
          300: '#b0b0b6',
          400: '#85858e',
          500: '#686871',
          600: '#51515a',
          700: '#3f3f48',
          800: '#27272f',
          900: '#1a1a22',
          950: '#0f0f16',
        },
        navy: {
          50: '#f0f4f8',
          100: '#dfe7f1',
          200: '#c5d4e3',
          300: '#9bb6cc',
          400: '#6a8fae',
          500: '#487095',
          600: '#365878',
          700: '#2a4762',
          800: '#223a51',
          900: '#1c3042',
          950: '#141f2b',
        },
        accent: {
          50: '#fdf8f3',
          100: '#faeee0',
          200: '#f4d8bc',
          300: '#edb88e',
          400: '#e09a63',
          500: '#cf844a',
          600: '#b86c3c',
          700: '#965432',
          800: '#7a442f',
          900: '#643a2b',
          950: '#381c15',
        },
        stone: {
          25: '#fcfbf9',
          50: '#faf9f7',
          100: '#f4f3f0',
          200: '#e8e6e1',
        },
      },
      fontFamily: {
        sans: ['"Inter"', 'system-ui', 'sans-serif'],
        serif: ['"Cormorant Garamond"', 'Georgia', 'serif'],
      },
      fontSize: {
        'display': ['3.25rem', { lineHeight: '1.05', letterSpacing: '-0.02em' }],
        'display-lg': ['4rem', { lineHeight: '1.02', letterSpacing: '-0.025em' }],
      },
      maxWidth: {
        'content': '1200px',
        'prose-narrow': '580px',
      },
      transitionTimingFunction: {
        'smooth': 'cubic-bezier(0.22, 1, 0.36, 1)',
      },
      animation: {
        'fade-in': 'fade-in 0.6s ease-out both',
        'fade-up': 'fade-up 0.7s cubic-bezier(0.22, 1, 0.36, 1) both',
        'slide-down': 'slide-down 0.3s ease-out both',
      },
      keyframes: {
        'fade-in': {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        'fade-up': {
          '0%': { opacity: '0', transform: 'translateY(24px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'slide-down': {
          '0%': { opacity: '0', transform: 'translateY(-10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
      },
    },
  },
  plugins: [],
};
